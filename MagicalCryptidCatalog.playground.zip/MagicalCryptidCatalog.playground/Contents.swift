import UIKit

func getFibonacciElement(at inputIndex: Int) -> Int {
    var fibonacciSeries: [Int] = []
    
    if inputIndex < 0 {
        return 0
    }
    for index in 0...inputIndex {
        if index < 2 {
            fibonacciSeries.append(index)
        }  else {
            let element1 = fibonacciSeries[fibonacciSeries.count - 1]
            let element2 = fibonacciSeries[fibonacciSeries.count - 2]
            fibonacciSeries.append(element1 + element2)
        }
        
    }
    return fibonacciSeries[inputIndex]
}

//getFibonacciElement(at: 10)


struct Creature {
    var name: String
    var description: String
    var isGood: Bool
    var magicPower: Int
    var ability: Int {
        return getFibonacciElement(at: magicPower)*(magicPower)
    }
    
    func interactWith(_ otherCreature: Creature) {
        switch (isGood, otherCreature.isGood){
        case (true, true): print("This creature and the other creature live in beautiful harmony and may even practive basket weaving together.")
        case (true, false): print("This creature had better watch out for the other creature.")
        case (false, true): print("The other creature had better watch out for this creature.")
        default: print("This is going to be a brutal fight to the death.")
        }
    }
}

      
    

let bigfoot = Creature(name: "Bigfoot", description: "A large hairy human shaped creature that lives in the shadows of North American forests.", isGood: true, magicPower: 2)

let lochNessMonster = Creature(name: "Loch Ness Monster", description: "A rarely-spotted plesiosaur-like creature that lives in Scotland's Loch Ness.", isGood: true, magicPower: 3)

let chupacabra = Creature(name: "Chupacabra", description: "A dog-like creature who sucks the blood of livestock.", isGood: false, magicPower: 4)

    

func describeCreature() {
    let creatureCatalog = [bigfoot, lochNessMonster, chupacabra]
    for creature in creatureCatalog {
        print(creature.name)
        print(creature.description)
        print("This creature's special ability level is \(creature.ability).")
        print("How \(creature.name) interacts with Bigfoot:")
        print(creature.interactWith(bigfoot))
        print("How \(creature.name) interacts with the Loch Ness Monster:")
        print(creature.interactWith(lochNessMonster))
        print("How \(creature.name) interacts with Chupacabra:")
        print(creature.interactWith(chupacabra))
    }
    
}
describeCreature()


    





